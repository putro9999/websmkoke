<?php

namespace App\Controllers;

class NotFound extends BaseController
{
    public function index($params)
    {
        return throw new \CodeIgniter\Exceptions\PageNotFoundException('Halaman yang anda cari tidak tersedia!');
    }
}
